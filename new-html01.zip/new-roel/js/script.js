var window_width;
			$(document).ready(function() {
				var window_width = $(window).width();
				
				/* Bootstrap tab to accordian */
				$('#myTab').tabCollapse();
				
				/* feature product slider */
				var feature_product_slide_owl = $("#feature_product_slide");
				feature_product_slide_owl.owlCarousel({
					itemsCustom : [
						[0, 1],
						[450, 2],
						[600, 3],
						[700, 3],
						[992, 4],
						[1200, 4],
						[1400, 4],
						[1600, 4]
					],
					navigation : false,
					pagination : false,
					autoPlay : true,
				});
				$(".feature_product_right_arrow").click(function(){
					feature_product_slide_owl.trigger('owl.next');
				});
				$(".feature_product_left_arrow").click(function(){
					feature_product_slide_owl.trigger('owl.prev');
				});
				
				/* sales_and_close_out slider */
				var sales_and_close_out_slide_owl = $("#sales_and_close_out_slide");
				sales_and_close_out_slide_owl.owlCarousel({
					itemsCustom : [
						[0, 1],
						[450, 2],
						[600, 3],
						[700, 3],
						[992, 4],
						[1200, 4],
						[1400, 4],
						[1600, 4]
					],
					navigation : false,
					pagination : false,
					autoPlay : true,
				});
				$(".sales_close_product_right_arrow").click(function(){
					sales_and_close_out_slide_owl.trigger('owl.next');
				});
				$(".sales_close_product_left_arrow").click(function(){
					sales_and_close_out_slide_owl.trigger('owl.prev');
				});
				
				/* leather_collections slider */
				var leather_collections_slide_owl = $("#leather_collections_slide");
				leather_collections_slide_owl.owlCarousel({
					itemsCustom : [
						[0, 1],
						[450, 2],
						[600, 3],
						[700, 3],
						[992, 4],
						[1200, 4],
						[1400, 4],
						[1600, 4]
					],
					navigation : false,
					pagination : false,
					autoPlay : true,
				});
				$(".leather_product_right_arrow").click(function(){
					leather_collections_slide_owl.trigger('owl.next');
				});
				$(".leather_product_left_arrow").click(function(){
					leather_collections_slide_owl.trigger('owl.prev');
				});
								
				// Custom Navigation Events
				$(".product_right_arrow").click(function(){
					if($(".featured_products").hasClass('active')){
						feature_product_slide_owl.trigger('owl.next');
					}else if($(".sales_and_close_out").hasClass('active')){
						sales_and_close_out_slide_owl.trigger('owl.next');
					}else if($(".leather_collections").hasClass('active')){
						leather_collections_slide_owl.trigger('owl.next');
					}
				});
				
				$(".product_left_arrow").click(function(){
					if($(".featured_products").hasClass('active')){
						feature_product_slide_owl.trigger('owl.prev');
					}else if($(".sales_and_close_out").hasClass('active')){
						sales_and_close_out_slide_owl.trigger('owl.prev');

					}else if($(".leather_collections").hasClass('active')){
						leather_collections_slide_owl.trigger('owl.prev');
					}
				});
				
				
				/* leather_collections slider */
				var watch_video_owl = $("#watch_video");
				watch_video_owl.owlCarousel({
					itemsCustom : [
						[0, 1],
						[450, 1],
						[600, 1],
						[700, 1],
						[1000, 1],
						[1200, 1],
						[1400, 1],
						[1600, 1]
					],
					navigation : false,
					pagination : true,
					autoPlay : true,
				});
				
				
				/* new_item_slider slider */
				var new_item_slider_owl = $("#new_item_slider");
				new_item_slider_owl.owlCarousel({
					itemsCustom : [
						[0, 1],
						[450, 1],
						[600, 2],
						[768, 3],
						[992, 4],
						[1200, 4],
						[1400, 4],
						[1600, 4]
					],
					navigation : false,
					pagination : false,
					autoPlay : true,
				});
				$(".new_item_left_arrow").on("click",function(){
					new_item_slider_owl.trigger('owl.prev');
				});
				$(".new_item_right_arrow").on("click",function(){
					new_item_slider_owl.trigger('owl.next');
				});
				
			topHeaderMenu();
			navigation_big_menu();
			addAccordian();
			$(window).resize(function(){
				topHeaderMenu();
				navigation_big_menu();
				addAccordian();
			});
			
			$(".dropdown").on('shown.bs.dropdown', function () {
				$(this).find(".dropdown-menu").addClass("animated wicket");
			});
			$(".dropdown").on('hide.bs.dropdown', function () {
				$(this).find(".dropdown-menu").addClass("wicketout");
			});
			$(".dropdown").on('hidden.bs.dropdown', function () {
				$(this).find(".dropdown-menu").removeClass("wicket wicketout");
			});
			
			$(".dropdown.vertical").on('shown.bs.dropdown', function () {
				$(this).find(".dropdown-menu").addClass("animated wicket2");
			});
			$(".dropdown.vertical").on('hidden.bs.dropdown', function () {
				$(this).find(".dropdown-menu").removeClass("wicket2 wicketout");
			});
			
			$(document).mouseup(function (e){
				var container = $("#Business_dropdown");			
				if (!container.is(e.target) && container.has(e.target).length === 0){
					$(".blank_white_bg_for_drodown.green").removeClass("show");
					$(".blank_white_bg_for_drodown.green").removeClass("wicket");
				}
				var container2 = $("#umbrellas_dropdown");
				if (!container2.is(e.target) && container2.has(e.target).length === 0){
					$(".blank_white_bg_for_drodown.yellow").removeClass("show");
					$(".blank_white_bg_for_drodown.yellow").removeClass("wicket");
				}
				var container3 = $("#drinkware_dropdown");			
				if (!container3.is(e.target) && container3.has(e.target).length === 0){
					$(".blank_white_bg_for_drodown.blue").removeClass("show");
					$(".blank_white_bg_for_drodown.blue").removeClass("wicket");
				}
				var container4 = $("#houseware_dropdown");
				if (!container4.is(e.target) && container4.has(e.target).length === 0){
					$(".blank_white_bg_for_drodown.red").removeClass("show");
					$(".blank_white_bg_for_drodown.red").removeClass("wicket");
				}
			});
			$(".filter-dropdown ul li > a").on("click",function(){
				$(".filter-dropdown > a > .dropdown-display").text($(this).text());
			});
			/*
			
			$('.navigation_dropdown').on('shown.bs.dropdown', function () {
				$(".blank_white_bg_for_drodown").addClass("show");
				$(".blank_white_bg_for_drodown").addClass($(this).attr("data-bg"));
				$(".blank_white_bg_for_drodown").html($(this).find(".dropdown-menu").html());
				
			});
			
			$('.navigation_dropdown').on('hidden.bs.dropdown', function () {
				
				if($(".blank_white_bg_for_drodown").hasClass("red")){
					$(".blank_white_bg_for_drodown").removeClass("red");
				}
				if($(".blank_white_bg_for_drodown").hasClass("blue")){
					$(".blank_white_bg_for_drodown").removeClass("blue");
				}
				if($(".blank_white_bg_for_drodown").hasClass("yellow")){
					$(".blank_white_bg_for_drodown").removeClass("yellow");
				}
				if($(".blank_white_bg_for_drodown").hasClass("green")){
					$(".blank_white_bg_for_drodown").removeClass("green");
				}
				$(".blank_white_bg_for_drodown").removeClass("show");
			});
			*/
				
			$('.lower_part').each(function(){
				$(this).css("background-image", "url(" +$(this).attr('data-background')+")");
				$(this).parallax('50%', $(this).attr('data-speed'));
			});
			$('.bottom_navigation_part a').hover(function () {
				var alt = $(this).find("img").attr("data-alt");
				$(this).find("img").attr("src",alt);
			}, function () {
				var rel = $(this).find("img").attr("data-rel");
				$(this).find("img").attr("src",rel);
			});
			
			
			
			
			/* Price range Slide Jquery UI*/
			$("#slider").slider({
				range: true,
				min: 0,
				max: 500,
				values: [ 30, 100 ],
				 slide: function( event, ui ) {
					$(".price_range_div .price_min_val").html("$"+ui.values[ 0 ]);
					$(".price_range_div .price_max_val").html("$"+ui.values[ 1 ]);
				}
			});
			$(".price_range_div .price_min_val").html("$"+$("#slider").slider( "values", 0 ));
			$(".price_range_div .price_max_val").html("$"+$("#slider").slider( "values", 1 ));
			
			
			/* grid view List view */
			$(".view-list a").click(function(){
				$(".view-list").addClass("active");
				$(".view-grid").removeClass("active");
				$(".product_list").addClass("list").removeClass("grid");
			});
			$(".view-grid a").click(function(){
				$(".view-grid").addClass("active");
				$(".view-list").removeClass("active");
				$(".product_list").addClass("grid").removeClass("list");
			});
			
			
			/* product gallery Page script */
			$(".product_gallery_page .carousel-inner .item .product_thumb_img_anchar").on('click',function(){
				var img_src = $(this).find("img").attr("src");
				$(".product_big_image").find("img").attr("src",img_src);
			});
			
			/* */
			$("a[rel^='prettyPhoto']").prettyPhoto();
			
			/* tab to accordian */
			$('#product_extra_info_tab').tabCollapse();

			/* Virtual Accordian */
			$('#virtual_page_accordion').on('shown.bs.collapse', function (e) {
				 $(e.target).prev().find(".fa-angle-double-left").removeClass("fa-angle-double-left").addClass("fa-angle-double-down");
				 $(e.target).parent('.list-group-item').addClass('active');
			});
			
			$('#virtual_page_accordion').on('hidden.bs.collapse', function (e) {
				$(this).find('.list-group-item').not($(e.target)).removeClass('active');
				$(this).find('.list-group-item > a > .pull-right > i').removeClass("fa-angle-double-down").addClass("fa-angle-double-left");
			});
			
			$("#qtySlider").slider({
				max: 999,
				change: function( event, ui ) {
					$("#qty_txt").val(ui.value);
				}
			});
			var qtyvalue = $("#qty_txt").val();
			$("#qty_txt").on("change",function(){
				$( "#qtySlider" ).slider( "option", "value", $(this).val());
			});
			$( "#qtySlider" ).slider( "option", "value", qtyvalue );
			
			/*$('#virtual_page_accordion > .list-group-item > a').on('click',function(e){
				$('#virtual_page_accordion > .list-group-item ').find('.collapse').removeClass("in");
			});*/
			
			/*
			$(".virtual_list_group .list-group-item a").on("click",function(){
				if($(this).next().hasClass("show")){
					$(this).next().removeClass('show');
					$(this).parent("li").removeClass("active");
				}else{
					$(".virtual_list_group .list-group-item").removeClass("active");
					$(".virtual_list_group .list-group-item .dr-menu").removeClass("show");
					
					$(this).parent("li").addClass("active");
					$(this).next().addClass("show");
				}
			});
			*/
			
			$(".membership .dropdown-menu a").on("click",function(){
				$(".dropdown-display").text($(this).attr("data-value"));
			});
			
			$('input[type=radio][name=membershipStatus]').change(function() {
				if (this.value == 'Yes') {
					$(".member_number_div").show();
				}
				else{
					$(".member_number_div").hide();
				}
			});
			
			
			$(".class_a").on("click",function(){
				$(this).next(".class_b").addClass("show animated wicket");
			});
					
			/*
			$(".form-groups .form-control").each(function(index, element) {
                $(element).focus(function(){
					$(element).parent().siblings(".form_label").hide();
				}).blur(function(){
					$(element).parent().siblings(".form_label").show();
				})
            });
			*/
			
			$(".qtyplus").on("click",function(){
				var inputVar = $(this).parent().siblings(".quantity-input");
				var qty_val =  inputVar.val();
				inputVar.val(parseInt(qty_val)+1);
			});
			$(".qtyminus").on("click",function(){
				var inputVar = $(this).parent().siblings(".quantity-input");
				var qty_val =  inputVar.val();
				inputVar.val(parseInt(qty_val)-1);
			});
			
			
			
			$(".sidecar-open").click(function(){
				if($(".sidecar").hasClass("open")){
					$(".sidecar").removeClass("open");
				}else{
					if($(".right_side_sidecar").hasClass("open")){
						$(".right_side_sidecar").removeClass("open");
					}
					$(".sidecar").addClass("open");
				}
			});
			
			$(".close_sidecar").click(function(){
				if($(".sidecar").hasClass("open")){
					$(".sidecar").removeClass("open");
				}
			});
			
			
			filter_side_bar_toggle();
			$(window).resize(function(){
				filter_side_bar_toggle();
			});
			
			$(".header-ellipsis").click(function(){
				if(!$(".right_side_sidecar").hasClass("open")){
					if($(".sidecar").hasClass("open")){
						$(".sidecar").removeClass("open");
					}
					$(".right_side_sidecar").addClass("open");
				}
			});
			$(".right_sidecar_panel_close").click(function(){
				if($(".right_side_sidecar").hasClass("open")){
					$(".right_side_sidecar").removeClass("open");
				}
			});
			
			/*checkout page */
			$("#continue").click(function(){
				$("#shipping_address_accordian").collapse('show');
			});
			
			/* ensure any open panels are closed before showing selected */
			$('#checkout_accordion').on('show.bs.collapse', function () {
				$('#checkout_accordion .in').collapse('hide');
			});
			/*
			$('#checkout_accordion .panel ').on('shown.bs.collapse', function () {
				$(this).find(".fa-caret-right").removeClass("fa-caret-right").addClass("fa-caret-down");
			});
			$('#checkout_accordion .panel ').on('hidden.bs.collapse', function () {
				$(this).find(".fa-caret-down").removeClass("fa-caret-down").addClass("fa-caret-right");
			});
			
			$('#shipping_billing_address_accordion .panel ').on('shown.bs.collapse', function () {
				$(this).find(".fa-caret-right").removeClass("fa-caret-right").addClass("fa-caret-down");
			});
			$('#shipping_billing_address_accordion .panel ').on('hidden.bs.collapse', function () {
				$(this).find(".fa-caret-down").removeClass("fa-caret-down").addClass("fa-caret-right");
			});
			*/
			
			$('.accordian_panel_group .panel ').on('shown.bs.collapse', function () {
				$(this).find(".fa-caret-right").removeClass("fa-caret-right").addClass("fa-caret-down");
			});
			$('.accordian_panel_group .panel ').on('hidden.bs.collapse', function () {
				$(this).find(".fa-caret-down").removeClass("fa-caret-down").addClass("fa-caret-right");
			});
						
			
			
			$('#mob_navbar .btn').click(function (e) {
				$("#navbar_menus > div").removeClass('in');
				var v = $(this).attr("data-target")
				if($(v).hasClass("in")){
					$(v).removeClass("in");
				}else{
					$(v).collapse('show');
				}
				
			});
			
			adjustTopFixedBar();
			$(window).on('scroll',function() {
				adjustTopFixedBar();
			});
			
			$("#carousel-example-generic").swipe({
				swipe:function(event, direction, distance, duration, fingerCount, fingerData) {
					if(direction == "right"){
						$(this).carousel('prev');
					}else if(direction == "left"){
						$(this).carousel('next');
					}
				}
			});
		});
		function topHeaderMenu(){
			window_width = $(window).width();
			if(window_width < 768){
				$(".right_side_sidecar .header-icon").each(function( index, element ) {
					$(element).find("[data-toggle='dropdown']").attr({"data-toggle":"collapse","data-target":"#col"+index}).addClass("collapsed");
					$(element).find(".dropdown-menu").attr("id","col"+index);
					$(element).find(".dropdown-menu").addClass("collapse").removeClass("dropdown-menu");
				});
				/*
				var menuRight = document.getElementById('cbp-spmenu-s2'),
				showRightPush = document.getElementById('showRightPush'),
						body = document.body;
						
				showRightPush.onclick = function() {
					classie.toggle( this, 'active' );
					classie.toggle( body, 'cbp-spmenu-push-toleft' );
					classie.toggle( menuRight, 'cbp-spmenu-open' );
				};*/
			}else{
				$(".right_side_sidecar .header-icon > a").each(function( index, element ) {
					$(element).removeAttr("data-toggle");
					$(element).removeAttr("data-target");
					$(element).removeClass("collapsed");
					$(element).next().removeAttr("id");
					$(element).next().removeAttr("style");
					$(element).next().removeClass("collapse");
					$(element).attr({"data-toggle":"dropdown"})
					$(element).next().addClass("dropdown-menu");
					$(element).parent().removeClass(".open");
				});
			}
		}
		function navigation_big_menu(){
			window_width = $(window).width();
			if(window_width > 767){
				$(".nav_drop").on("click",function(){
					var color = $(this).parent().parent().attr("data-bg");
					$("."+color).addClass("show");
					$("."+color).addClass("animated wicket");
				});
			}
		}
		
		function addAccordian(){
			window_width = $(window).width();
			if(window_width < 768){
				$(".middle_footer .heading").each(function( index, element ) {
					$(element).attr({"data-toggle":"collapse","data-target":"#demo"+index});
					$(element).addClass("collapsed");
					$(element).next().attr("id","demo"+index);
					$(element).next().addClass("collapse");					
				});
			}else{
				$(".middle_footer .heading").each(function( index, element ) {
					$(element).removeAttr("data-toggle");
					$(element).removeAttr("data-target");
					$(element).removeClass("collapsed");
					$(element).next().removeAttr("id");
					$(element).next().removeClass("collapse");
				});
			}
			//$(".collapsed").collapse();
		}
		
		
		
		
		function filter_side_bar_toggle(){
			window_width = $(window).width();
			if(window_width < 991){
				$(".sidecar").swipe( {
					//Generic swipe handler for all directions
					swipe:function(event, direction, distance, duration, fingerCount, fingerData) {
						if(direction == "left"){
							$(".sidecar").removeClass("open");
						}
					},
					//Default is 75px, set to 0 for demo so any distance triggers swipe
				   threshold:0
				});
			}
		}
		
		
		function setFileName(fileName) {    
			/* Manipulate file name here */
			$("#txtFile").text(fileName);
		}
		
		function adjustTopFixedBar(){
			var scrolltop = $(this).scrollTop();
			if(scrolltop >= $('.main_section_container').offset().top) {
				/*$('#fixed_header').removeClass("hide").addClass("show");*/
				$('#fixed_header').slideDown();
    		}else if(scrolltop <= $('.main_section_container').offset().top-5) {
				/*$('#fixed_header').removeClass("show").addClass("hide");*/
				$('#fixed_header').slideUp();
			}
		}